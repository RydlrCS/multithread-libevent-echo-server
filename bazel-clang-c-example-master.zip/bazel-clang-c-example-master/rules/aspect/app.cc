#include "aspect/lib.h"
#include <iostream>

int main() {
  std::cout << number() << std::endl;
}
