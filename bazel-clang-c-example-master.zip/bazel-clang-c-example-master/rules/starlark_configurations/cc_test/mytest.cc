// a trivially passing test

int main() {
	return 0;
}