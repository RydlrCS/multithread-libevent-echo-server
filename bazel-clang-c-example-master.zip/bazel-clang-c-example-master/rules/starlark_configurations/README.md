### Starlark Build Configuration Examples

This directory contains examples of how to use [Starlark Build Configurations](https://docs.bazel.build/versions/master/skylark/config.html).