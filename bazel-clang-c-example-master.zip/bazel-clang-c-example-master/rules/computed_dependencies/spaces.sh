#!/bin/bash
tr -d ' ' < $1 > $2  # Remove spaces
